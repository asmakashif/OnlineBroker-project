	<!-- Copy right start -->
	<div class="copy-right">
		<div class="container">
			<div class="row clearfix">
				<div class="col-md-8 col-sm-12">
					&copy;  2019 <a href="http://ARSCnetwork.com/" target="_blank">ARSC Networks</a>. All rights reserved.
				</div>
				<div class="col-md-4 col-sm-12">
					<ul class="social-list clearfix">
						<li>
							<a href="https://www.facebook.com/ARSCNetworks" target="_blank" class="facebook">
								<i class="fa fa-facebook"></i>
							</a>
						</li>
						<li>
							<a href="https://twitter.com/ARSCNetworks" target="_blank" class="twitter">
								<i class="fa fa-twitter"></i>
							</a>
						</li>
						<li>
							<a href="https://www.linkedin.com/company/ARSCNetworks" target="_blank" class="linkedin">
								<i class="fa fa-linkedin"></i>
							</a>
						</li>
						<li>
							<a href="https://www.youtube.com/user/ARSCNetworks" target="_blank" class="youtube">
								<i class="fa fa-youtube"></i>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- Copy end right-->
	<script src="<?php echo base_url('assets/');?>js/bootstrap.min.js"></script>
	<script src="<?php echo base_url('assets/');?>js/bootstrap-submenu.js"></script>
	<script src="<?php echo base_url('assets/');?>js/rangeslider.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.mb.YTPlayer.js"></script>
	<script src="<?php echo base_url('assets/');?>js/wow.min.js"></script>
	<script src="<?php echo base_url('assets/');?>js/bootstrap-select.min.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.easing.1.3.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.scrollUp.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="<?php echo base_url('assets/');?>js/dropzone.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.filterizr.js"></script>
	<script src="<?php echo base_url('assets/');?>js/jquery.magnific-popup.min.js"></script>
	<script src="<?php echo base_url('assets/');?>js/maps.js"></script>
	<script src="<?php echo base_url('assets/');?>js/app.js"></script>
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<script src="<?php echo base_url('assets/');?>js/ie10-viewport-bug-workaround.js"></script>
	<!-- Custom javascript -->
	<script src="<?php echo base_url('assets/');?>js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>