<?php $this->load->view('admin/include/header'); ?>
<?php $this->load->view('admin/include/topbar'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('admin/include/footer'); ?>